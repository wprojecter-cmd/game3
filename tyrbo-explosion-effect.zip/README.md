# Explosion

Explosions for a three.js scene: a flash, a rolling fireball, smoke, sparks, embers, a shockwave
racing across the ground, a scorch mark, dust thrown off the ground, and chunks of debris that
bounce and glow as they cool. Made by [Tyrbo](https://tyrbo.ai) and free under CC0.

## Use it

Copy `explosion.js` into your game. It imports only `three` (written for 0.186).

```js
import { createExplosions } from './explosion.js';

const explosions = createExplosions(scene); // a pool, made once

// a barrel goes up:
explosions.explode(barrel.position, 1.2);

// every frame, with the seconds since the last one:
explosions.update(dt);
```

The size scales everything together: the fireball, how far the sparks fly, the shockwave and the
debris. A size of 1 is a fireball about two units across. For a shake, nudge your camera for a
moment after `explode()`; the demo shows one way.

To see it, serve this folder (browsers load modules only over http), for example with
`npx serve .`, and open `demo.html`. Tap the ground to set one off.

## Options

Every option is optional.

| Option    | Default   | What it does                                                                                         |
| --------- | --------- | ---------------------------------------------------------------------------------------------------- |
| `slots`   | 6         | Blasts alive at once; a seventh reuses the oldest.                                                   |
| `debris`  | 10        | Chunks each blast throws; 0 for none.                                                                |
| `ground`  | 0         | Height of the ground. The shockwave, scorch and dust need a blast near it, and debris bounces on it. |
| `light`   | 60        | Peak intensity of the flash's point light; 0 for none.                                               |
| `scorch`  | `true`    | Leave a burn mark that fades over a few seconds.                                                     |
| `ambient` | 1         | How lit the smoke and dust are: 1 for daylight, about 0.45 at night.                                 |
| `hot`     | `#fff2c0` | The hottest fire and the flash.                                                                      |
| `fire`    | `#ff7418` | The fire, and the light it casts.                                                                    |
| `smoke`   | `#38332f` | The smoke.                                                                                           |
| `dust`    | `#6f6253` | The dust thrown off the ground.                                                                      |
| `rock`    | `#4a433d` | The debris.                                                                                          |
| `seed`    | random    | The same seed gives the same blasts.                                                                 |

A green alien blast: `createExplosions(scene, { hot: '#eaffd0', fire: '#3ee05a', smoke: '#1f2a22' })`.

## What it gives back

- `explode(position, size = 1)`: sets off a blast at a point in the world.
- `update(dt)`: moves every blast on by `dt` seconds. Call it once a frame.
- `object`: the group holding the pool; leave it at the origin.
- `light`: the flash's point light, or `null`.
- `dispose()`: removes it from the scene and frees its GPU memory.

## How it works

The pool's particles are made once: every blast's flash, fire, smoke, sparks, embers, dust,
shockwave and scorch mark are instances of one quad, drawn in one call. `explode()` writes the
blast's place and time into its slot, and the vertex shader works out each particle's path from
its seed, with drag and gravity, so nothing is made or thrown away while the game runs. The
debris is one instanced mesh of three's standard material, moved on the CPU while it flies. Fire
adds its light like a screen blend, so a blast glows at night and still reads in daylight. It
follows the scene's fog and the renderer's tone mapping.

## License

CC0 1.0 Universal (see `LICENSE.txt`): use it in any project, commercial or not, change it as
you like, no credit needed.
